# Software Engineering 

### Education
- Bachelor's in Software Engineering

### Languages
- Java
- Python
  
### Projects
- **Real Estate**: This application is a console-based real estate management system that allows users to interact with property listings and bids. Upon launching the app, users are presented with a main menu that includes two primary options: Listings and Bids. Within the Listings section, users can add new property listings, view existing listings, or auto-populate sample listings using a development tool. Each listing includes detailed property information such as residence type, address, zip code, square footage, number of bedrooms and bathrooms, yard or floor details, as well as appraisal and list prices.
In the Bids section, users can submit new bids on available properties, view bids already placed, or use a development tool to auto-generate bids. Properties are listed with the number of bids they’ve received, allowing users to select a property and view its associated bidding activity. The system appears to be structured for internal use, such as by a real estate agency or development team, given its inclusion of dev tools and direct console input prompts.

- **Dessert Shop**: This application is a console-based dessert ordering system that allows users to build and process custom dessert orders. The main menu provides options to add different dessert items to an order, including Candy, Cookie, Ice Cream, and Sundae, as well as access to an Admin Module. When adding items, the user is prompted to input relevant details such as the name, quantity (e.g., weight for candy or number of scoops for ice cream), and pricing. Once the user finalizes the order, the app collects the customer's name and preferred payment method (cash, card, or phone). A detailed receipt is then generated, showing itemized costs, tax per item, subtotal, total tax, and grand total. The system also tracks customer information, including a unique customer ID and total number of orders. This app appears to be designed for small dessert shops or vendors looking for a straightforward, interactive point-of-sale system.

- **BlackJack Game**: This application is a visually customized Blackjack game built using Java, combining object-oriented programming with a simple graphical interface. The game uses a structured class design, featuring components like BJDeck, BJHand, and supporting test classes to simulate and verify game logic such as card behavior, deck management, and hand evaluation. The PlayBlackJack class serves as the entry point, where a PGame class is used to launch the main game interface. The interface has been personalized with custom colors, fonts, and layout elements to enhance the visual experience, including a green table background, black banners, and orange-highlighted buttons. The game pits a player hand against a dealer hand in a traditional round of Blackjack, offering an interactive and educational implementation ideal for learning Java GUI development and game logic. The project was developed as part of a lab assignment to reinforce key programming concepts like class construction, GUI customization, and modular design.

### Ethical Dilemma Analysis
- **Theme**: Integrity in Code and Character
  
During a group software engineering project, one of my teammates submitted code that they had copied directly from an online repository without any attribution. The code was part of a core functionality we were assigned to build ourselves, and it immediately raised red flags for me during a code review. At first, I wasn't sure how to handle the situation. I knew reporting the issue might damage our team’s dynamic and possibly get my teammate in trouble, but ignoring it would make me complicit in academic dishonesty and go against my personal values.
I decided to speak to the teammate privately and asked about the origin of the code. They admitted to copying it, saying they were overwhelmed and didn’t want to fall behind. I empathized with their stress but explained the seriousness of the situation. After giving it some thought, I decided to report the incident to our instructor, but I also offered to help the teammate rewrite the code from scratch so we could submit original work.

This experience taught me that ethical decisions are rarely easy, especially when they involve people you work closely with. According to the ACM Code of Ethics, being honest and respecting others' intellectual work are core professional responsibilities. Upholding these values not only protects my credibility but also reinforces the culture of integrity in software development. Ultimately, acting with integrity meant having the courage to do what was right, even when it was uncomfortable.
